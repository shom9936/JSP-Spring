package common;

public class MyCommons {

//	public static class Visit() {
//		public static final String VIEW_PATH ="/WEB-INF/views/visit";
//	}
//	
}
